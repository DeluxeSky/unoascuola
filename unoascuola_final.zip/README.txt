Leggi le istruzioni nel file README (usa uvicorn server:app --reload per test locale)
