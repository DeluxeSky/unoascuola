from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
import random

app = FastAPI()
app.mount("/", StaticFiles(directory="static", html=True), name="static")

COLORI = ["Red","Yellow","Green","Blue"]
SPECIALI = ["Skip","Reverse","DrawTwo"]
WILDS = ["Wild","WildDrawFour"]

stanze = {}

class Manager:
    def __init__(self):
        self.conn = {}

    async def connect(self, ws: WebSocket, room: str, name: str):
        await ws.accept()
        if room not in self.conn:
            self.conn[room] = {}
        if len(self.conn[room]) >= 4:
            await ws.send_text("Stanza piena (max 4 giocatori).")
            await ws.close()
            return False
        self.conn[room][name] = ws
        await self.broadcast(room, f"{name} si è unito alla stanza.")
        return True

    def disconnect(self, ws: WebSocket, room: str, name: str):
        if room in self.conn:
            self.conn[room].pop(name, None)

    async def send_personal(self, room: str, name: str, msg: str):
        if room in self.conn and name in self.conn[room]:
            try:
                await self.conn[room][name].send_text(msg)
            except:
                pass

    async def broadcast(self, room: str, msg: str):
        if room in self.conn:
            for ws in list(self.conn[room].values()):
                try:
                    await ws.send_text(msg)
                except:
                    pass

manager = Manager()

def crea_mazzo():
    mazzo = []
    for c in COLORI:
        for i in range(0,10):
            mazzo.append(f"{c}_{i}")
        for s in SPECIALI:
            mazzo.append(f"{c}_{s}")
    mazzo += WILDS*4
    random.shuffle(mazzo)
    return mazzo

@app.websocket("/ws/{room}/{name}")
async def websocket_endpoint(ws: WebSocket, room: str, name: str):
    ok = await manager.connect(ws, room, name)
    if not ok:
        return
    if room not in stanze:
        stanze[room] = {
            "deck": crea_mazzo(),
            "discard": [],
            "players": {},
            "order": [],
            "turn_index": 0,
            "direction": 1,
            "mode": "Normale",
            "pending_draw": 0,
            "pending_type": None
        }
    r = stanze[room]
    r["players"][name] = []
    r["order"].append(name)
    for _ in range(7):
        if r["deck"]:
            r["players"][name].append(r["deck"].pop())
    await manager.send_personal(room, name, f"Le tue carte: {', '.join(r['players'][name])}")
    if not r["discard"] and r["deck"]:
        c = r["deck"].pop()
        r["discard"].append(c)
        await manager.broadcast(room, f"Carta iniziale: {c}")
    await manager.broadcast(room, f"Modalità: {r['mode']}")
    await manager.broadcast(room, f"Tocca a: {r['order'][r['turn_index']]}")
    try:
        while True:
            data = await ws.receive_text()
            if data.startswith("SETMODE"):
                parts = data.split()
                if len(parts) > 1 and parts[1] in ["Normale","Ribattuta"]:
                    r["mode"] = parts[1]
                    await manager.broadcast(room, f"Modalità: {r['mode']}")
                continue
            if data.startswith("Gioca carta"):
                parts = data.split()
                idx = int(parts[2])
                wild_color = parts[3] if len(parts) > 3 else None
                if idx < 0 or idx >= len(r["players"][name]):
                    await manager.send_personal(room, name, "Indice carta non valido.")
                    continue
                card = r["players"][name][idx]
                if r["pending_draw"] > 0:
                    if r["mode"] == "Ribattuta" and r["pending_type"] == "DrawTwo" and "DrawTwo" in card:
                        r["pending_draw"] += 2
                        r["players"][name].pop(idx)
                        r["discard"].append(card)
                        await manager.broadcast(room, f"{name} ha giocato {card} (stack)")
                    elif r["mode"] == "Ribattuta" and r["pending_type"] == "WildDrawFour" and "WildDrawFour" in card:
                        r["pending_draw"] += 4
                        r["players"][name].pop(idx)
                        r["discard"].append(card)
                        await manager.broadcast(room, f"{name} ha giocato {card} (stack)")
                    else:
                        await manager.send_personal(room, name, "Non puoi giocare quella carta durante una catena di pesca. Devi pescare o accettare la penalità.")
                        continue
                else:
                    if "Wild" in card and wild_color:
                        card = card + "_" + wild_color
                    r["discard"].append(card)
                    r["players"][name].pop(idx)
                    await manager.broadcast(room, f"{name} ha giocato {card}")
                    if "DrawTwo" in card:
                        r["pending_draw"] = 2
                        r["pending_type"] = "DrawTwo"
                    elif "WildDrawFour" in card:
                        r["pending_draw"] = 4
                        r["pending_type"] = "WildDrawFour"
                    elif "Skip" in card:
                        r["turn_index"] = (r["turn_index"] + r["direction"]) % len(r["order"])
                        await manager.broadcast(room, f"{r['order'][r['turn_index']]} è saltato!")
                    elif "Reverse" in card:
                        r["direction"] *= -1
                        await manager.broadcast(room, "Cambio direzione!")
                if len(r["players"][name]) == 0:
                    await manager.broadcast(room, f"{name} ha vinto la partita!")
                    r["players"].pop(name, None)
                    break
                r["turn_index"] = (r["turn_index"] + r["direction"]) % len(r["order"])
                await manager.broadcast(room, f"Tocca a: {r['order'][r['turn_index']]}")
                for pname, ws_conn in list(manager.conn[room].items()):
                    mano = r["players"].get(pname, [])
                    await manager.send_personal(room, pname, f"Le tue carte: {', '.join(mano)}")
            elif data == "Pesca carta":
                if r["pending_draw"] > 0:
                    count = r["pending_draw"]
                    drawn = []
                    for _ in range(count):
                        if r["deck"]:
                            drawn.append(r["deck"].pop())
                    r["players"][name].extend(drawn)
                    r["pending_draw"] = 0
                    r["pending_type"] = None
                    await manager.send_personal(room, name, f"Hai pescato: {', '.join(drawn)}")
                    await manager.send_personal(room, name, f"Le tue carte: {', '.join(r['players'][name])}")
                else:
                    if r["deck"]:
                        c = r["deck"].pop()
                        r["players"][name].append(c)
                        await manager.send_personal(room, name, f"Hai pescato: {c}")
                        await manager.send_personal(room, name, f"Le tue carte: {', '.join(r['players'][name])}")
                    else:
                        await manager.send_personal(room, name, "Il mazzo è vuoto.")
                r["turn_index"] = (r["turn_index"] + r["direction"]) % len(r["order"])
                await manager.broadcast(room, f"Tocca a: {r['order'][r['turn_index']]}")
            elif data == "UNO!":
                await manager.broadcast(room, f"{name} ha detto UNO!")
    except WebSocketDisconnect:
        manager.disconnect(ws, room, name)
        await manager.broadcast(room, f"{name} si è disconnesso dalla stanza.")
